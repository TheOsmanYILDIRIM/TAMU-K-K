# Osman live-rig assets — replaces the retired spritesheet experiment

Approved user source: `osman_saglak_4yon_v5.rigby`.
Source SHA-256: `86ed6aa3e40a082b9f7b67e9074a2d3b1149facb9c785a9e44956397ab22ad92`.

`rig.json` retains the 40-bone / 24-slot / 44-clip snapshot and its original
key times, values, curves, draw order and influences. Only JSON null attachment
values are represented by false for the game's strict asset JSON reader.
`images/` contains the original 30 PNG parts byte-for-byte (24 are referenced).
These are body-part textures, NOT animation frames. No character spritesheet
is required or rendered. `directions.json` is the approved anatomical right-hand
mapping. Reflection is already keyed in each clip; never apply another flipX.

Runtime: `player/rigby_runtime.lua` (continuous evaluation / CPU skinning) and
`player/rigby_visual.lua` (persistent LÖVE meshes, crossfade, right-hand socket).
This is the approved FK snapshot profile, not a general Rigby importer: all
44 source clips explicitly set all 8 IK mixes to zero. Active IK, deform and
other unsupported constraint timelines are rejected, not silently ignored.

Rollback: set `TAMU_USE_PLASMA=1`. Original core/plasma code and assets are
unchanged and retained in Git and the .love package. No save schema change.
The .love is a review build; no main merge or actual Android verification.

Reference semantics and test oracle: Rigby2D pose.js blob
`07ee2d8da26a5a12df190943eb7812fbefb6c892` from the user's fork. The reference
fixture was evaluated with the actual editor JS runtime, not this Lua port.
The following notice covers the referenced/adapted runtime semantics; it does
not grant third-party rights to the user's character artwork.

MIT License

Copyright (c) 2026 jaisurya-dev-art

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
