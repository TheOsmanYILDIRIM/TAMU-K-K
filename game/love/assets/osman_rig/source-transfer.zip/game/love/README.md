# Oyun — LÖVE2D 2D world runtime

The 2D engine lives in `game/love/` on `main`, with an
independent `experiment/world-2d-design-20261012` history. The Godot 3D scaffold
in the repository root is **historical**, not the agreed 45-degree 2D direction.
The branch is intentionally isolated: do not merge the old branch wholesale
into `main`, because `main` contains newer Object Studio changes.

## Run

Install LÖVE 11.5 on desktop and launch from repository root:

```sh
love game/love
```

Keyboard: WASD/arrows pan the camera; mouse drag to pan, wheel to zoom,
click polygon to select, R to reset, Escape to clear. On Android:
one-finger drag pans, tap selects, two-finger pinch zooms; on-screen
+/−/R controls work with touch. UI accommodates portrait dimensions,
resizes and safe-area insets.

The main entrypoint now includes seeded continuous terrain, Marching Squares,
chunk streaming, player physics/A*, object harvesting and traversable water.
Resource gameplay constants are generated from JSON catalog for packaged LÖVE.
The older polygon scene remains a Stage 1 test fixture. Stage5 crafting, inventory and workbench placement are playable on main.
Stage6 save/recovery and detached Stage5 transaction bridge are opt-in only
via OSMAN_STAGE6_EXPLICIT=1 and an explicit world UUID. Autosave and crash-
durable Android filesystem guarantees remain unverified; no production save
is silently created. Android APK and networking are not yet verified. World units are continuous,
no visible tilemap.

## Test

```sh
cd game/love
lua5.4 tests/run.lua
lua5.4 tests/runtime.lua
find . -name '*.lua' -print0 | xargs -0 -n1 luac5.4 -p
```

GitHub Actions `LOVE biome core validation` performs Lua syntax and unit
tests and launches the real LÖVE render loop under Xvfb for three frames
on the experiment branch. CI proves startup/render smoke, **not** visual
correctness or Android compatibility. Those require real engine and device
tests in subsequent work.

## Boundaries

Preserve backup branch, `main`, World Builder, Terrain Studio, Object Studio,
other experiment branches, external assets, IndexedDB, and user saves.
No texture files were added; existing 18 terrain variants are out of scope.

## Core stat progression V1 (session-only)

Player gains general character XP from successful RAM-only resource harvest/craft/build.
Character level rewards free stat points; STATS touch panel or keyboard P spends them.
Core Level is separate: all six stats share a ceiling and all Core types share normal
skill capacity at the same Core level. Future skill definitions unlock typed actions
and earn separate usage XP; feat/proficiency systems are not adopted.

Run: cd game/love && lua5.4 tests/core_stat_progression.lua
Also run LuaJIT, quality CI and real LÖVE/Xvfb production UI smoke.

IMPORTANT: numeric curves are provisional. This demo does NOT upgrade Core,
transfer consciousness, activate skills, or persist progression in save_v2.
Stage6 explicit play does NOT award session XP to avoid non-atomic cross-save commits.
The HUD displays SESSION ONLY / NOT SAVED. Do not mistake test snapshot/restore
for production durable saving. A new versioned save contract and migration are required.

## Manual performance investigation: 10x long traversal (expensive)

Run **only** after chunk streaming, terrain, GPU allocation, cache, camera, or
memory behavior changes, when investigating frame stalls, or before a risky
performance release. **Do not** run for routine edits, small tests, asset/UI
changes, or every CI push. Standard Lua regression parses the profiler only;
the full traversal is never part of routine `quality.yml`.

From the repository root, on a system with LÖVE, Python3, `timeout` and
optionally Xvfb:

```sh
bash game/love/tests/run_r2_long_traversal.sh
```

The script uses an **isolated disposable XDG_DATA_HOME** and three real-engine
runs (cache off / cold / warm), with the same seed, 10x scripted world-space
movement and two laps across a large area. Each **actual rendered frame** gets
wall-clock frame-ms/derived instantaneous FPS, update/terrain/object timings,
mesh allocation call durations, cache counters, resident/pending/build jobs,
memory and GPU-reported counters in CSV. A separate timestamped event log
correlates sudden spikes with chunk generation/eviction, mesh completion,
cache reads/writes, background prefetch, and large heap drops. One JSON summary
per mode gives p50/p95/p99/max and stall counts. Evidence is retained in the
path printed by the runner, which has a default 120-second **per-mode** timeout
(overridable with `OSMAN_PROFILE_TIMEOUT_SEC`). The test's virtual 10x travel
speed does **not** accelerate actual CPU/GPU work, and it does **not** validate
player collision, Android hardware FPS, or GPU execution timestamps.

The expensive GitHub cache workflow is explicitly `workflow_dispatch`-only;
the long-run test can be run manually with the script above when needed. Do not
treat an unexecuted or skipped long-run test as passing.


## Live Rigby character review — 2026-10-29

Only `experiment/osman-rigby-4dir-20261029`: approved Osman four-direction,
right-handed rig replaces the previous frame-atlas experiment. Normal gameplay
uses `player.rigby_visual`; `TAMU_USE_PLASMA=1` restores the unchanged core/plasma
renderer. `main` is not merged and the previous core design remains historical
context for this experiment, not permission to delete it.

The runtime evaluates the original sparse keys and Bezier curves every draw,
then updates persistent LÖVE meshes from bone weights. The asset profile is
`tamu-rigby-fk/1`: all 44 approved clips disable IK. Active IK/deform/other
constraints are rejected. This is not a universal Rigby runtime.

Gameplay selects idle/walk plus mine/chop for current harvesting. All 44 clips
can be evaluated; `require("player.rigby_visual").play(player,action,false)`
selects a visual-only one-shot. No combat or running mechanic is fabricated.
`right_hand(player,screen_x,screen_y,camera.zoom)` returns the animated socket
matrix, including reflection. Items are intentionally not drawn yet.

Targeted tests: `lua tests/rigby_runtime.lua`, `lua tests/rigby_visual.lua`.
The first compares 264 poses with the actual editor reference; the latter is a
mock graphics integration test, NOT GPU evidence. `TAMU_RIGBY_SMOKE=1 love .`
runs the real LÖVE mesh test and captures all 44 clips. Normal production
entrypoint smoke uses `OSMAN_LOVE_INTEGRATION_SMOKE=1 love .`.
Actual Android device/FPS and user visual acceptance remain open.
