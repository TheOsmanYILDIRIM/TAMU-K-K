# TAMU — yeni ana karakter için Godot 4 uyarlama paketi

Kaynak: TAMU_Walk.zip içindeki `TAMU_walk.r2d.json`, altı özgün PNG. **Ön/üç-çeyrek görünüş**, arka görünüş yok. Hareket yönüne göre mevcut `main.gd` yatay aynalamayı uygular.

Hedef: `TheOsmanYILDIRIM/TAMU-K-K`, `experiment/limboai-godot46-20261104` dalı.

## Uygulama

1. Mevcut `scripts/profile_rig.gd` dosyasını **yedekleyin**; paketteki dosyayla değiştirin.
2. `assets/profile_character/rev2d/` dizinini aynı yola kopyalayın. **Eski `motion.json` ve diğer kaynakları silmeyin**.
3. `main.gd` dokunulmadan `ProfileRig.new()`, `setup()`, `verify_contract()`, `set_clip()` ve `advance()` çağrıları devam eder.
4. Kaynakta `idle` ve `walk` vardır. Oyun `run` isterse geçici olarak yürüyüş klibi hız/distance oranıyla kullanılır. `slash`, `stab` henüz mevcut olmadığı için yeni karakter bunlarda idle'a düşer. Geri/diğer açılar üretilmemiştir.

## Önemli durum

Bu, **kaynak uyarlama paketi**, CI kabulü ya da cihaza yüklenmiş oyun sürümü değildir. Bu oturumda Godot yürütücüsü olmadığı için GDScript parse, render, APK, telefonda test yapılmadı. 41 kemik, altı Polygon2D mesh, mesh ağırlıkları, iki Rev2D klip ve parametre bağları korunacak şekilde kod yazıldı. Gerekli nihai kabul: Godot 4 parser, oyun sahnesi, animasyon görseli, mobil performans ve kontrol testleri. `scripts/profile_rig_ci.gd` eski 23 kemik/7 klip sözleşmesine bağımlı olabilir; yeni kaynak için güncellenmeden eski testleri geçer varsaymayın.

**GitHub'a push yapılmadı**, Avenox Beyin görev kaydı yazılmadı. Bu paket tek başına otomatik dal güncellemesi değildir.
