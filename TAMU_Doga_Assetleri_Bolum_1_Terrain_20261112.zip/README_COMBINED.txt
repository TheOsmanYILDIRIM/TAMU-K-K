TAMU assets combined 2026-11-12
8 tree folders: trees/<species>/albedo.png, normal.png
6 terrain folders: terrain/<material>/albedo.png, height.png, normal.png
Original source metadata: metadata/trees/, metadata/terrain/
Backup older grass maps: alternatives/forest_grass_initial/
Original image bytes preserved. Provisional: skyward_forest_oak normal resized/alpha corrected in source set.
Archive is transfer only, not a Godot asset file. Unpack into repo appropriate locations.
WARNING: ~49 MiB exceeds GitHub browser file upload limit (25 MiB per file).
