# TAMU — Sekiz Ağaç: Albedo + Normal Map

Sekiz ağaç ve sekiz normal map aynı ağaç klasörlerinde bulunur.

Her klasör: `trees/<id>/albedo.png` ve `trees/<id>/normal.png`.

**ÖNEMLİ: `skyward_forest_oak/normal.png` GEÇİCİ DÜZELTİLMİŞTİR.** Kaynak `125511.png` (1536×1536, RGB) şeffaf değildir: mavi-mor arka plan gerçekte piksellere boyanmıştır. 1254×1254'e yeniden boyutlandırıldı ve karşılık gelen albedonun alpha kanalı eklendi. Bu işlem görünür arka planı kaldırır ama yeniden ölçekleme, normal vektörlerinin kesinliğini veya iç detayların birebir hizasını garanti etmez. Oyun için son onay öncesi kontrol edin. Kaynak bozulmadan `review_originals/125511_opaque_rgb_original.png` içinde korunur.

Diğer 7 normal map orijinal RGBA dosya baytlarıyla, değiştirilmeden korunmuştur. Kenar alfaları ile albedo kenarlarının piksel bazında tam aynı olduğu garanti edilmez. İçerik GPT Image üretimidir ve oyun motorunda gerçek ışık tepkisi henüz doğrulanmamıştır.

Eşleştirme, görüntü alpha silüetlerinin karşılaştırılması ve ağaç anatomisinin kontrolüyle yapılmıştır. Türler önceki TAMU tasarım etiketleridir, botanik teşhis değildir. `manifest.json` SHA256 ve kaynak eşleştirmelerini verir.
