# TAMU — Terrain materyal dosyaları (2026-11-12)

Bu ZIP, sohbet içerisinde kullanıcı tarafından paylaşılan görsellerin **orijinal dosya baytlarını değiştirmeden** yeniden adlandırır. Hiçbir texture yeniden üretilmedi veya sessizce filtrelenmedi. Oyun koduna eklenmedi; GitHub'a yükleme yapılmadı.

## Klasör yapısı

`terrain/<material_id>/albedo.png` — ana renk materyali.

`terrain/<material_id>/height.png` — Gri tonlu yüzey yüksekliği; beyaz daha yüksek.

`terrain/<material_id>/normal.png` — GPT Image ile üretilen tangent-space OpenGL (+Y) normal görseli; matematiksel doğruluğu garanti değil.

Her harita 1536×1536 PNG'dir. Ayrıntılı köken eşlemesi `source_mapping.csv`, SHA-256 ve kenar farkları `manifest.json` içinde.

## Malzemeler

- `forest_grass` — Ana çimenli orman zemini (Çimen kümeleri, yaprak döküntüsü ve koyu toprak); albedo `125125476.png`, height `125125480.png`, normal `125125481.png`.
- `forest_rocky` — Kayalık orman zemini (Kırık açılı taşlar, çakıl, az yosun, yaprak döküntüsü); albedo `125125488.png`, height `125125489.png`, normal `125125490.png`.
- `forest_sparse_litter` — Seyrek yapraklı orman toprağı (Ezilmiş kahverengi toprak, kuru yapraklar, ince kök ve az taş); albedo `125125491.png`, height `125125492.png`, normal `125125493.png`.
- `forest_roots_litter` — Kök ve yaprak döküntülü orman zemini (Belirgin yüzey kökleri, bol meşe yaprağı, yosun ve az taş); albedo `125125496.png`, height `125125494.png`, normal `125125495.png`.
- `conifer_needle_litter` — İğne yapraklı orman zemini (Çam iğneleri, humus, küçük kozalak kırıntısı ve yosun); albedo `125125497.png`, height `125125498.png`, normal `125125499.png`.
- `forest_moss_pebbles` — Yosunlu çakıllı orman toprağı (Küçük yuvarlak taşlar, seyrek meşe yaprakları, ince dallar ve yosun); albedo `125125502.png`, height `125125500.png`, normal `125125501.png`.

## Ek / eski sürüm

`alternatives/forest_grass_initial/` eski height `125477.png` ve normal `125478.png` içerir. Ana materyalin height `125480.png`, normal `125481.png` sürümü günceldir; albedo `125476.png` ortaktır.

## Teknik uyarılar

- Dosyaların kare ve katman olarak eşlenmiş olması **tam seamless** olduklarını kanıtlamaz. Orijinal dosyalarda karşı kenar piksel uyuşmazlıkları ölçülmüştür; otomatik dikiş düzeltmesi uygulanmadı. Tekrarlama dikişleri oyunda test edilmeli.
- Height ve GPT normal haritaları aynı görsel desenleri genel olarak takip etse de normal vektörleri height eğimlerinden matematiksel olarak türetilmiş değildir; shader öncesi yön/renk kodlaması, gamma ve dinamik ışık kontrolü gerektirir.
- Her malzeme ayrı `albedo + normal + height` seti olarak kullanılabilir. Height map kullanımı zorunlu değildir; performans için albedo-only / albedo+normal karşılaştırılmalıdır.
- Bu altı malzeme görsele göre isimlendirildi; özellikle **nehir kıyısı, bataklık ve açıkça tanımlanmış toprak yol** dokuları bu yüklemelerden doğrulanmadı. Bunlar tamamlandı diye işaretlenmedi.
- Kullanıcı görselleri kaynak olarak korunur; lisans veya kullanım haklarına ilişkin ek sertifika üretilmedi.

## GitHub

`terrain/` klasörü ve `manifest.json` depoya taşınabilir. Mevcut oyun kaynak yapısı/asset yolu doğrulanmadan otomatik repo klasörü değişikliği veya runtime entegrasyonu yapılmadı.
